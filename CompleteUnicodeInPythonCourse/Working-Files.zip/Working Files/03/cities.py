cities = u'Basel Genève Zürich'.split()

for city in cities:
    print(city)
